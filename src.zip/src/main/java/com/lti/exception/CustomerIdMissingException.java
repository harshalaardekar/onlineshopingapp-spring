package com.lti.exception;

public class CustomerIdMissingException extends Exception {
	
	
	public CustomerIdMissingException(String message) {
		super(message);
	}
}
