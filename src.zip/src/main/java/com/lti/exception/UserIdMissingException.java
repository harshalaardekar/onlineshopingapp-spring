package com.lti.exception;

public class UserIdMissingException extends Exception {
	
	
	public UserIdMissingException(String message) {
		super(message);
	}
}
