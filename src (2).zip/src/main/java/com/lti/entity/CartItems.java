package com.lti.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_cartitems")
public class CartItems {
	
	@Id
	@SequenceGenerator(name = "cart_seq", initialValue = 1000, allocationSize = 1)
	@GeneratedValue(generator = "cart_seq", strategy = GenerationType.SEQUENCE)
	int itemsId;
	double totalprice;
	int quantity;
	
	@ManyToOne
	@JoinColumn(name ="cartId")
	Cart cart;
	
	@OneToOne
	@JoinColumn(name="productId")
	Product product;

	public int getItemsId() {
		return itemsId;
	}

	public void setItemsId(int itemsId) {
		this.itemsId = itemsId;
	}

	public double getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	
	
	
	
	

}
